# Иконка приложения

В проект добавлена иконка с сурикатом из изображения пользователя.

Файлы:
- app/src/main/res/drawable/ic_launcher_foreground.png — foreground для adaptive icon Android 8+
- app/src/main/res/mipmap-*/ic_launcher.png — legacy icon
- app/src/main/res/mipmap-*/ic_launcher_round.png — round icon

Ничего дополнительно делать не нужно: при сборке APK Android возьмёт эту иконку автоматически.
