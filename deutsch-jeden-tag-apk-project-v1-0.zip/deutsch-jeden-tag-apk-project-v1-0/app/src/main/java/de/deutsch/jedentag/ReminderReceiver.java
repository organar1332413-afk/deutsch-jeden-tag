package de.deutsch.jedentag;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        ReminderScheduler.showNotification(context, intent.getStringExtra("title"), intent.getStringExtra("body"));
        ReminderScheduler.scheduleFromPrefs(context);
    }
}
