package de.deutsch.jedentag;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 2001;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 2002;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private final ArrayList<SpeechItem> ttsList = new ArrayList<>();
    private int ttsIndex = 0;
    private int ttsPauseMs = 250;
    private boolean ttsStopped = true;
    private boolean ttsPaused = false;
    private boolean ttsPausable = false;
    private int ttsRunId = 0;

    private String preferredDeVoiceName = "";
    private String preferredRuVoiceName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) WebView.setWebContentsDebuggingEnabled(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                MainActivity.this.filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                    fallback.addCategory(Intent.CATEGORY_OPENABLE);
                    fallback.setType("*/*");
                    startActivityForResult(Intent.createChooser(fallback, "Выбери JSON-файл"), FILE_CHOOSER_REQUEST);
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidTtsBridge(), "AndroidTTS");
        webView.addJavascriptInterface(new AndroidReminderBridge(), "AndroidReminder");
        webView.addJavascriptInterface(new AndroidFileBridge(), "AndroidFile");

        initTts();
        ReminderScheduler.createChannel(this);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                preferredDeVoiceName = getPreferences(MODE_PRIVATE).getString("voice_de", "");
                preferredRuVoiceName = getPreferences(MODE_PRIVATE).getString("voice_ru", "");
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) { handleTtsDone(utteranceId); }
                    @Override public void onError(String utteranceId) { handleTtsDone(utteranceId); }
                });
            }
        });
    }

    private void handleTtsDone(String utteranceId) {
        final int runId = parseRunId(utteranceId);
        runOnUiThread(() -> {
            if (runId != ttsRunId) return;
            if (ttsStopped || ttsPaused) return;
            ttsIndex += 1;
            if (webView != null) webView.postDelayed(MainActivity.this::speakNext, ttsPauseMs);
        });
    }

    private int parseRunId(String utteranceId) {
        try {
            if (utteranceId == null) return -1;
            int idx = utteranceId.indexOf(":");
            if (idx <= 0) return -1;
            return Integer.parseInt(utteranceId.substring(0, idx));
        } catch (Exception e) { return -1; }
    }

    private void speakNext() {
        if (ttsStopped || ttsPaused || !ttsReady || tts == null) return;
        if (ttsIndex >= ttsList.size()) {
            finishTtsQueue();
            return;
        }
        SpeechItem item = ttsList.get(ttsIndex);
        applyVoiceOrLanguage(item);
        try { tts.setSpeechRate(item.rate > 0 ? item.rate : 0.9f); } catch (Exception ignored) {}
        Bundle params = new Bundle();
        String utteranceId = ttsRunId + ":" + UUID.randomUUID();
        tts.speak(item.text, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
    }

    private void finishTtsQueue() {
        ttsStopped = true;
        ttsPaused = false;
        ttsPausable = false;
        ttsList.clear();
        ttsIndex = 0;
        notifyWebQueueDone();
    }

    private void notifyWebQueueDone() {
        if (webView == null) return;
        runOnUiThread(() -> {
            try { webView.evaluateJavascript("window.onAndroidTtsQueueDone && window.onAndroidTtsQueueDone();", null); }
            catch (Exception ignored) {}
        });
    }

    private Locale localeForLang(String lang) {
        return lang != null && lang.startsWith("ru") ? new Locale("ru", "RU") : new Locale("de", "DE");
    }

    private String preferredVoiceForLang(String lang) {
        return lang != null && lang.startsWith("ru") ? preferredRuVoiceName : preferredDeVoiceName;
    }

    private void savePreferredVoice(String lang, String voiceName) {
        String clean = voiceName == null ? "" : voiceName.trim();
        if (lang != null && lang.startsWith("ru")) {
            preferredRuVoiceName = clean;
            getPreferences(MODE_PRIVATE).edit().putString("voice_ru", clean).apply();
        } else {
            preferredDeVoiceName = clean;
            getPreferences(MODE_PRIVATE).edit().putString("voice_de", clean).apply();
        }
    }

    private void applyVoiceOrLanguage(SpeechItem item) {
        Locale fallbackLocale = localeForLang(item.lang);
        String selectedVoice = item.voiceName != null && !item.voiceName.trim().isEmpty()
                ? item.voiceName.trim()
                : preferredVoiceForLang(item.lang);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && selectedVoice != null && !selectedVoice.isEmpty()) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice voice : voices) {
                        if (selectedVoice.equals(voice.getName())) {
                            tts.setVoice(voice);
                            return;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        try { tts.setLanguage(fallbackLocale); } catch (Exception ignored) {}
    }

    private void stopTts() {
        ttsRunId += 1;
        ttsStopped = true;
        ttsPaused = false;
        ttsPausable = false;
        ttsList.clear();
        ttsIndex = 0;
        if (tts != null) tts.stop();
    }

    private void startQueue(String json, int pauseMs, boolean pausable) {
        try {
            if (tts != null) tts.stop();
            ttsRunId += 1;
            ttsList.clear();
            ttsIndex = 0;
            ttsPauseMs = Math.max(80, pauseMs);
            ttsStopped = false;
            ttsPaused = false;
            ttsPausable = pausable;
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String text = o.optString("text", "").trim();
                if (text.isEmpty()) continue;
                SpeechItem item = new SpeechItem();
                item.text = text;
                item.lang = o.optString("lang", "de-DE");
                item.voiceName = o.optString("voice", "");
                item.rate = (float) o.optDouble("rate", item.lang.startsWith("ru") ? 0.95 : 0.9);
                ttsList.add(item);
            }
            speakNext();
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, "Ошибка озвучки", Toast.LENGTH_SHORT).show();
        }
    }

    private void pausePausableQueue() {
        if (!ttsPausable || ttsStopped) return;
        ttsPaused = true;
        if (tts != null) tts.stop();
    }

    private void resumePausableQueue() {
        if (!ttsPausable || ttsStopped) return;
        ttsPaused = false;
        speakNext();
    }

    private void requestPostNotificationsPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
        }
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private static class SpeechItem { String text; String lang; String voiceName; float rate; }

    public class AndroidTtsBridge {
        @JavascriptInterface public String getVoices(String lang) {
            try {
                JSONArray arr = new JSONArray();
                if (tts == null || !ttsReady || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return arr.toString();
                Locale target = localeForLang(lang);
                Set<Voice> voices = tts.getVoices();
                if (voices == null) return arr.toString();
                for (Voice voice : voices) {
                    Locale loc = voice.getLocale();
                    if (loc == null) continue;
                    if (!loc.getLanguage().equals(target.getLanguage())) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", voice.getName());
                    o.put("locale", loc.toLanguageTag());
                    o.put("quality", voice.getQuality());
                    o.put("latency", voice.getLatency());
                    o.put("network", voice.isNetworkConnectionRequired());
                    arr.put(o);
                }
                return arr.toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public String getSelectedVoice(String lang) {
            return preferredVoiceForLang(lang);
        }

        @JavascriptInterface public void setVoice(String lang, String voiceName) {
            runOnUiThread(() -> savePreferredVoice(lang, voiceName));
        }

        @JavascriptInterface public void speakTest(String lang, String voiceName, String text) {
            runOnUiThread(() -> {
                try {
                    JSONArray arr = new JSONArray();
                    JSONObject o = new JSONObject();
                    o.put("text", text == null || text.trim().isEmpty() ? (lang != null && lang.startsWith("ru") ? "Проверка русского голоса" : "Deutsche Stimmprobe") : text.trim());
                    o.put("lang", lang == null || lang.isEmpty() ? "de-DE" : lang);
                    o.put("voice", voiceName == null ? "" : voiceName);
                    o.put("rate", o.optString("lang", "de-DE").startsWith("ru") ? 0.95 : 0.9);
                    arr.put(o);
                    startQueue(arr.toString(), 200, false);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Ошибка проверки голоса", Toast.LENGTH_SHORT).show(); }
            });
        }

        @JavascriptInterface public void speakQueue(String json, int pauseMs) {
            runOnUiThread(() -> startQueue(json, pauseMs, false));
        }

        @JavascriptInterface public void speakPausableQueue(String json, int pauseMs) {
            runOnUiThread(() -> startQueue(json, pauseMs, true));
        }

        @JavascriptInterface public void pausePausable() {
            runOnUiThread(MainActivity.this::pausePausableQueue);
        }

        @JavascriptInterface public void resumePausable() {
            runOnUiThread(MainActivity.this::resumePausableQueue);
        }

        @JavascriptInterface public void stop() { runOnUiThread(MainActivity.this::stopTts); }
    }

    public class AndroidReminderBridge {
        @JavascriptInterface public void requestPermission() { runOnUiThread(MainActivity.this::requestPostNotificationsPermission); }
        @JavascriptInterface public void showNow(String title, String body) {
            runOnUiThread(() -> { requestPostNotificationsPermission(); ReminderScheduler.showNotification(MainActivity.this, title, body); });
        }
        @JavascriptInterface public void schedule(String json) {
            runOnUiThread(() -> { requestPostNotificationsPermission(); ReminderScheduler.saveAndSchedule(MainActivity.this, json); Toast.makeText(MainActivity.this, "Напоминания запланированы", Toast.LENGTH_SHORT).show(); });
        }
    }

    public class AndroidFileBridge {
        @JavascriptInterface public void saveText(String filename, String text) {
            runOnUiThread(() -> {
                try {
                    String safeName = filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                    OutputStream out;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        ContentResolver resolver = getContentResolver();
                        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new IllegalStateException("Cannot create file");
                        out = resolver.openOutputStream(uri);
                    } else {
                        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        if (dir == null) dir = getFilesDir();
                        out = new FileOutputStream(new File(dir, safeName));
                    }
                    if (out == null) throw new IllegalStateException("Cannot open file");
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                    out.flush(); out.close();
                    Toast.makeText(MainActivity.this, "Сохранено: " + safeName, Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Не удалось сохранить файл", Toast.LENGTH_LONG).show(); }
            });
        }
    }
}
