package de.deutsch.jedentag;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public final class ReminderScheduler {
    private static final String PREFS = "deutsch_reminders";
    private static final String KEY_SCHEDULE = "schedule_json";
    private static final String CHANNEL_ID = "lesson_reminders";
    private ReminderScheduler() {}

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Напоминания уроков", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Напоминания пройти урок немецкого");
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public static void saveAndSchedule(Context context, String json) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_SCHEDULE, json).apply();
        scheduleAlarms(context, json);
    }
    public static void scheduleFromPrefs(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SCHEDULE, null);
        if (json != null) scheduleAlarms(context, json);
    }
    public static void scheduleAlarms(Context context, String json) {
        cancelKnownAlarms(context);
        try {
            JSONObject root = new JSONObject(json);
            if (!root.optBoolean("enabled", false)) return;
            JSONArray reminders = root.optJSONArray("reminders");
            JSONArray daysArr = root.optJSONArray("days");
            if (reminders == null || daysArr == null || daysArr.length() == 0) return;
            Set<Integer> days = new HashSet<>();
            for (int i = 0; i < daysArr.length(); i++) days.add(daysArr.optInt(i));
            String title = root.optString("title", "Пора пройти урок чешского");
            String body = root.optString("body", "Открой приложение и пройди короткий урок.");
            for (int i = 0; i < reminders.length(); i++) {
                JSONObject r = reminders.getJSONObject(i);
                if (!r.optBoolean("enabled", false)) continue;
                long trigger = nextTriggerMillis(r.optString("time", "09:00"), days);
                if (trigger > 0) scheduleOne(context, i, trigger, title, body);
            }
        } catch (Exception ignored) {}
    }

    private static void scheduleOne(Context context, int slot, long triggerAtMillis, String title, String body) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("body", body);
        intent.putExtra("slot", slot);
        intent.setPackage(context.getPackageName());

        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                5000 + slot,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent showIntent = PendingIntent.getActivity(
                context,
                8000 + slot,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        try {
            // Для учебных напоминаний используем AlarmClock: на Xiaomi/Android он надёжнее,
            // чем обычный setAndAllowWhileIdle, и не теряется после закрытия приложения.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                alarmManager.setAlarmClock(new AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent), pi);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            }
        } catch (Exception e) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
                }
            } catch (Exception ignored) {}
        }
    }
    private static void cancelKnownAlarms(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        for (int slot = 0; slot < 2; slot++) {
            Intent intent = new Intent(context, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, 5000 + slot, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) alarmManager.cancel(pi);
        }
    }
    private static long nextTriggerMillis(String time, Set<Integer> jsDays) {
        try {
            String[] parts = time.split(":");
            int hour = Integer.parseInt(parts[0]); int minute = Integer.parseInt(parts[1]);
            Calendar now = Calendar.getInstance();
            for (int add = 0; add <= 7; add++) {
                Calendar target = (Calendar) now.clone();
                target.add(Calendar.DAY_OF_YEAR, add);
                target.set(Calendar.HOUR_OF_DAY, hour); target.set(Calendar.MINUTE, minute); target.set(Calendar.SECOND, 0); target.set(Calendar.MILLISECOND, 0);
                int jsDay = target.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? 0 : target.get(Calendar.DAY_OF_WEEK) - 1;
                if (jsDays.contains(jsDay) && target.getTimeInMillis() > now.getTimeInMillis()) return target.getTimeInMillis();
            }
        } catch (Exception ignored) {}
        return -1;
    }
    public static void showNotification(Context context, String title, String body) {
        createChannel(context);
        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(context, 7000, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_stat_cestina)
                .setContentTitle(title == null || title.isEmpty() ? "Пора пройти урок чешского" : title)
                .setContentText(body == null || body.isEmpty() ? "Открой приложение и пройди короткий урок." : body)
                .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
                .setContentIntent(contentIntent).setAutoCancel(true).build();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1001, notification);
    }
}
